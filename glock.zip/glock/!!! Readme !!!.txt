Custom Skin!

Combat Pistol Nami one piece By xSmayka

How to install This Pistol

Go to the file path on open IV

update > x64 > dlcpacks > patchday8ng > dlc > x64 > models > cdimages > weapons.rpf

drag and drop the files with edit mode enabled

Gun Made by:

xSmayka ;)
	Enjoy >3